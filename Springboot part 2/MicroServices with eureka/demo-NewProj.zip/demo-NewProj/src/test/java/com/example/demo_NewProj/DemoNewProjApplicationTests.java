package com.example.demo_NewProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoNewProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
